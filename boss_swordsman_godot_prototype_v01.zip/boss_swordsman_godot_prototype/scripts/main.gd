extends Node2D

# ============================================================
# Prototype 02 — visual/audio vertical slice
# แตะหน้าจอ -> เดินอัตโนมัติ -> เจอสไลม์ -> Auto Battle
# -> EXP / แกนเวทย์ -> ใช้ Potion ได้หลังจบการต่อสู้เท่านั้น
# ============================================================

const MOVE_SPEED := 95.0
const WALK_FPS := 9.0
const ARRIVAL_DISTANCE := 6.0
const BOSS_IDLE_RIGHT := preload("res://assets/characters/boss/exploration/boss_idle_right.png")
const BOSS_IDLE_LEFT := preload("res://assets/characters/boss/exploration/boss_idle_left.png")
const BOSS_IDLE_FRONT := preload("res://assets/characters/boss/exploration/boss_idle_front.png")
const BOSS_IDLE_BACK := preload("res://assets/characters/boss/exploration/boss_idle_back.png")
const BOSS_WALK_RIGHT_1 := preload("res://assets/characters/boss/exploration/walk_right/boss_walk_right_1.png")
const BOSS_WALK_RIGHT_2 := preload("res://assets/characters/boss/exploration/walk_right/boss_walk_right_2.png")
const BOSS_WALK_RIGHT_3 := preload("res://assets/characters/boss/exploration/walk_right/boss_walk_right_3.png")
const BOSS_WALK_RIGHT_4 := preload("res://assets/characters/boss/exploration/walk_right/boss_walk_right_4.png")
const BOSS_WALK_RIGHT_5 := preload("res://assets/characters/boss/exploration/walk_right/boss_walk_right_5.png")
const BOSS_WALK_RIGHT_6 := preload("res://assets/characters/boss/exploration/walk_right/boss_walk_right_6.png")
const BOSS_WALK_LEFT_1 := preload("res://assets/characters/boss/exploration/walk_left_v3/boss_walk_left_v3_1.png")
const BOSS_WALK_LEFT_2 := preload("res://assets/characters/boss/exploration/walk_left_v3/boss_walk_left_v3_2.png")
const BOSS_WALK_LEFT_3 := preload("res://assets/characters/boss/exploration/walk_left_v3/boss_walk_left_v3_3.png")
const BOSS_WALK_LEFT_4 := preload("res://assets/characters/boss/exploration/walk_left_v3/boss_walk_left_v3_4.png")
const BOSS_WALK_LEFT_5 := preload("res://assets/characters/boss/exploration/walk_left_v3/boss_walk_left_v3_5.png")
const BOSS_WALK_LEFT_6 := preload("res://assets/characters/boss/exploration/walk_left_v3/boss_walk_left_v3_6.png")
const BOSS_WALK_DOWN_1 := preload("res://assets/characters/boss/exploration/walk_down_v1/boss_walk_down_1.png")
const BOSS_WALK_DOWN_2 := preload("res://assets/characters/boss/exploration/walk_down_v1/boss_walk_down_2.png")
const BOSS_WALK_DOWN_3 := preload("res://assets/characters/boss/exploration/walk_down_v1/boss_walk_down_3.png")
const BOSS_WALK_DOWN_4 := preload("res://assets/characters/boss/exploration/walk_down_v1/boss_walk_down_4.png")
const BOSS_WALK_DOWN_5 := preload("res://assets/characters/boss/exploration/walk_down_v1/boss_walk_down_5.png")
const BOSS_WALK_DOWN_6 := preload("res://assets/characters/boss/exploration/walk_down_v1/boss_walk_down_6.png")
const BOSS_WALK_UP_1 := preload("res://assets/characters/boss/exploration/walk_up_v1/boss_walk_up_1.png")
const BOSS_WALK_UP_2 := preload("res://assets/characters/boss/exploration/walk_up_v1/boss_walk_up_2.png")
const BOSS_WALK_UP_3 := preload("res://assets/characters/boss/exploration/walk_up_v1/boss_walk_up_3.png")
const BOSS_WALK_UP_4 := preload("res://assets/characters/boss/exploration/walk_up_v1/boss_walk_up_4.png")
const BOSS_WALK_UP_5 := preload("res://assets/characters/boss/exploration/walk_up_v1/boss_walk_up_5.png")
const BOSS_WALK_UP_6 := preload("res://assets/characters/boss/exploration/walk_up_v1/boss_walk_up_6.png")
const BATTLE_BG := preload("res://assets/visual/battle_grassland.png")
const BOSS_BATTLE := preload("res://assets/visual/boss_battle_v2.png")
const SLIME_BATTLE := preload("res://assets/visual/slime_battle.png")
const BATTLE_THEME := preload("res://assets/audio/battle_theme.wav")
const SFX_SWING := preload("res://assets/audio/swing.wav")
const SFX_HIT := preload("res://assets/audio/hit.wav")
const SFX_VICTORY := preload("res://assets/audio/victory.wav")

# ---------- Player balance ----------
var player_level := 1
var player_max_hp := 60
var player_hp := 60
var player_atk := 10
var player_def := 2
var player_spd := 6
var player_exp := 0
var small_magic_core := 0
var potions := 2

# EXP รวมที่ใช้ขึ้นเลเวล
var exp_thresholds := [0, 100, 280, 560, 960]

# ---------- Slime Lv.1 ----------
const SLIME_MAX_HP := 24
const SLIME_ATK := 4
const SLIME_DEF := 0
const SLIME_SPD := 2
const SLIME_EXP := 12

var slime_hp := SLIME_MAX_HP
var slime_active := true
var slime_kills := 0

# ---------- World state ----------
var player: CharacterBody2D
var player_sprite: AnimatedSprite2D
var slime: Node2D
var target_position := Vector2.ZERO
var has_target := false
var in_battle := false
var post_battle := false
var player_was_defeated := false
var facing_direction := "right"

# ---------- UI ----------
var hud_label: Label
var quest_label: Label
var hint_label: Label

var battle_panel: Panel
var battle_status: Label
var boss_hp_bar: ProgressBar
var slime_hp_bar: ProgressBar
var boss_avatar: TextureRect
var slime_avatar: TextureRect
var boss_damage_label: Label
var slime_damage_label: Label
var battle_music: AudioStreamPlayer
var sfx_player: AudioStreamPlayer

var post_panel: Panel
var post_title: Label
var post_text: Label
var potion_button: Button
var continue_button: Button


func _ready() -> void:
	randomize()
	_build_world()
	_build_ui()
	_refresh_hud()
	queue_redraw()


# ============================================================
# WORLD
# ============================================================

func _build_world() -> void:
	# Player
	player = CharacterBody2D.new()
	player.name = "Boss"
	player.position = Vector2(160, 390)
	add_child(player)

	var frames := SpriteFrames.new()
	_add_animation(frames, "idle_right", [BOSS_IDLE_RIGHT], 1.0)
	_add_animation(frames, "idle_left", [BOSS_IDLE_LEFT], 1.0)
	_add_animation(frames, "idle_down", [BOSS_IDLE_FRONT], 1.0)
	_add_animation(frames, "idle_up", [BOSS_IDLE_BACK], 1.0)
	_add_animation(frames, "walk_right", [BOSS_WALK_RIGHT_1, BOSS_WALK_RIGHT_2, BOSS_WALK_RIGHT_3, BOSS_WALK_RIGHT_4, BOSS_WALK_RIGHT_5, BOSS_WALK_RIGHT_6], WALK_FPS)
	_add_animation(frames, "walk_left", [BOSS_WALK_LEFT_1, BOSS_WALK_LEFT_2, BOSS_WALK_LEFT_3, BOSS_WALK_LEFT_4, BOSS_WALK_LEFT_5, BOSS_WALK_LEFT_6], WALK_FPS)
	_add_animation(frames, "walk_down", [BOSS_WALK_DOWN_1, BOSS_WALK_DOWN_2, BOSS_WALK_DOWN_3, BOSS_WALK_DOWN_4, BOSS_WALK_DOWN_5, BOSS_WALK_DOWN_6], WALK_FPS)
	_add_animation(frames, "walk_up", [BOSS_WALK_UP_1, BOSS_WALK_UP_2, BOSS_WALK_UP_3, BOSS_WALK_UP_4, BOSS_WALK_UP_5, BOSS_WALK_UP_6], WALK_FPS)

	player_sprite = AnimatedSprite2D.new()
	player_sprite.name = "BossExplorationSprite"
	player_sprite.sprite_frames = frames
	player_sprite.animation = "idle_right"
	player_sprite.centered = true
	player_sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	player.add_child(player_sprite)

	var player_name := Label.new()
	player_name.text = "บอส"
	player_name.position = Vector2(-24, -102)
	player_name.add_theme_font_size_override("font_size", 18)
	player.add_child(player_name)

	# Camera follows player so the scenery visibly scrolls while walking.
	var camera := Camera2D.new()
	camera.position_smoothing_enabled = true
	camera.position_smoothing_speed = 6.0
	camera.enabled = true
	player.add_child(camera)

	# Slime
	slime = Node2D.new()
	slime.name = "SlimeLv1"
	slime.position = Vector2(760, 390)
	add_child(slime)

	var slime_shape := Polygon2D.new()
	slime_shape.polygon = PackedVector2Array([
		Vector2(-34, 22),
		Vector2(-30, -6),
		Vector2(-18, -30),
		Vector2(0, -42),
		Vector2(18, -30),
		Vector2(30, -6),
		Vector2(34, 22),
		Vector2(0, 34)
	])
	slime_shape.color = Color("#4fbde8")
	slime.add_child(slime_shape)

	var slime_name := Label.new()
	slime_name.text = "Slime Lv.1"
	slime_name.position = Vector2(-48, -78)
	slime_name.add_theme_font_size_override("font_size", 17)
	slime.add_child(slime_name)


func _add_animation(frames: SpriteFrames, animation_name: StringName, textures: Array, fps: float) -> void:
	frames.add_animation(animation_name)
	frames.set_animation_loop(animation_name, true)
	frames.set_animation_speed(animation_name, fps)
	for texture in textures:
		frames.add_frame(animation_name, texture)


func _draw() -> void:
	# Large field
	draw_rect(Rect2(-2600, -500, 5200, 1800), Color("#68a94f"))

	# Dirt road
	draw_rect(Rect2(-2600, 315, 5200, 170), Color("#c9aa73"))
	draw_line(Vector2(-2600, 315), Vector2(2600, 315), Color("#8d744f"), 4.0)
	draw_line(Vector2(-2600, 485), Vector2(2600, 485), Color("#8d744f"), 4.0)

	# Decorative distant hills / trees — all move with the camera.
	for x in range(-2400, 2500, 420):
		draw_circle(Vector2(x, 185), 90.0, Color("#4c8e45"))
		draw_circle(Vector2(x + 100, 220), 65.0, Color("#579a4c"))

	# Fence posts along the route
	for x in range(-2400, 2500, 180):
		draw_rect(Rect2(x, 260, 12, 58), Color("#725135"))
		draw_rect(Rect2(x, 510, 12, 58), Color("#725135"))

	# A simple town silhouette in the far left
	draw_rect(Rect2(-1000, 90, 320, 190), Color("#d7c5a6"))
	draw_rect(Rect2(-900, 10, 90, 270), Color("#b9a37f"))
	draw_colored_polygon(
		PackedVector2Array([
			Vector2(-1030, 90), Vector2(-840, -45), Vector2(-650, 90)
		]),
		Color("#496f9f")
	)


func _physics_process(_delta: float) -> void:
	if in_battle or post_battle:
		player.velocity = Vector2.ZERO
		_play_idle()
		return

	if has_target:
		var delta_pos := target_position - player.global_position
		if delta_pos.length() <= ARRIVAL_DISTANCE:
			has_target = false
			player.velocity = Vector2.ZERO
			_play_idle()
			hint_label.text = "หยุดแล้ว — แตะจุดใดก็ได้เพื่อเดินต่อ"
		else:
			player.velocity = delta_pos.normalized() * MOVE_SPEED
			_update_facing(player.velocity)
			player_sprite.play("walk_" + facing_direction)
			player.move_and_slide()
	else:
		_play_idle()

	if slime_active and player.global_position.distance_to(slime.global_position) < 82.0:
		_start_battle()


func _unhandled_input(event: InputEvent) -> void:
	if in_battle or post_battle:
		return

	var pressed := false
	var screen_pos := Vector2.ZERO

	if event is InputEventScreenTouch:
		pressed = event.pressed
		screen_pos = event.position
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		pressed = event.pressed
		screen_pos = event.position

	if pressed:
		var inv_canvas := get_viewport().get_canvas_transform().affine_inverse()
		var touched_world: Vector2 = inv_canvas * screen_pos
		if touched_world.distance_to(player.global_position) > ARRIVAL_DISTANCE:
			target_position = touched_world
			has_target = true
			hint_label.text = "กำลังเดินไปยังจุดที่แตะ — ทดสอบท่าเดิน 4 ทิศ"


func _update_facing(direction: Vector2) -> void:
	if abs(direction.x) > abs(direction.y):
		facing_direction = "right" if direction.x > 0.0 else "left"
	else:
		facing_direction = "down" if direction.y > 0.0 else "up"


func _play_idle() -> void:
	player_sprite.play("idle_" + facing_direction)


# ============================================================
# UI
# ============================================================

func _build_ui() -> void:
	var canvas := CanvasLayer.new()
	add_child(canvas)

	hud_label = Label.new()
	hud_label.position = Vector2(24, 18)
	hud_label.add_theme_font_size_override("font_size", 22)
	canvas.add_child(hud_label)

	quest_label = Label.new()
	quest_label.position = Vector2(24, 56)
	quest_label.add_theme_font_size_override("font_size", 20)
	canvas.add_child(quest_label)

	hint_label = Label.new()
	hint_label.text = "ทดสอบ Walk Cycle 4 ทิศ — แตะจุดใดก็ได้เพื่อเดิน"
	hint_label.position = Vector2(24, 675)
	hint_label.add_theme_font_size_override("font_size", 18)
	canvas.add_child(hint_label)

	# ---------- Battle panel ----------
	battle_panel = Panel.new()
	battle_panel.position = Vector2(20, 20)
	battle_panel.size = Vector2(1240, 680)
	battle_panel.visible = false
	var panel_style := StyleBoxFlat.new()
	panel_style.bg_color = Color("#071426")
	panel_style.border_color = Color("#5ee7ff")
	panel_style.set_border_width_all(4)
	panel_style.set_corner_radius_all(18)
	battle_panel.add_theme_stylebox_override("panel", panel_style)
	canvas.add_child(battle_panel)

	var battle_bg := TextureRect.new()
	battle_bg.texture = BATTLE_BG
	battle_bg.position = Vector2(8, 8)
	battle_bg.size = Vector2(1224, 664)
	battle_bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	battle_bg.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	battle_bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	battle_panel.add_child(battle_bg)

	var top_shade := ColorRect.new()
	top_shade.position = Vector2(8, 8)
	top_shade.size = Vector2(1224, 118)
	top_shade.color = Color(0.02, 0.06, 0.15, 0.82)
	top_shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	battle_panel.add_child(top_shade)

	var bottom_shade := ColorRect.new()
	bottom_shade.position = Vector2(8, 535)
	bottom_shade.size = Vector2(1224, 137)
	bottom_shade.color = Color(0.02, 0.06, 0.15, 0.86)
	bottom_shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	battle_panel.add_child(bottom_shade)

	var battle_title := Label.new()
	battle_title.text = "AUTO BATTLE"
	battle_title.position = Vector2(0, 22)
	battle_title.size = Vector2(1240, 44)
	battle_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	battle_title.add_theme_font_size_override("font_size", 28)
	battle_panel.add_child(battle_title)

	boss_avatar = TextureRect.new()
	boss_avatar.texture = BOSS_BATTLE
	boss_avatar.position = Vector2(115, 128)
	boss_avatar.size = Vector2(360, 390)
	boss_avatar.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	boss_avatar.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	boss_avatar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	battle_panel.add_child(boss_avatar)

	slime_avatar = TextureRect.new()
	slime_avatar.texture = SLIME_BATTLE
	# Lv.1 slime is intentionally smaller than the Boss and keeps the same ground line.
	slime_avatar.position = Vector2(861, 346)
	slime_avatar.size = Vector2(199, 146)
	slime_avatar.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	slime_avatar.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	slime_avatar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	battle_panel.add_child(slime_avatar)

	var boss_name := Label.new()
	boss_name.text = "บอส"
	boss_name.position = Vector2(65, 76)
	boss_name.add_theme_font_size_override("font_size", 22)
	battle_panel.add_child(boss_name)

	var slime_name := Label.new()
	slime_name.text = "Slime Lv.1"
	slime_name.position = Vector2(978, 76)
	slime_name.add_theme_font_size_override("font_size", 22)
	battle_panel.add_child(slime_name)

	boss_hp_bar = ProgressBar.new()
	boss_hp_bar.position = Vector2(65, 560)
	boss_hp_bar.size = Vector2(390, 34)
	boss_hp_bar.max_value = player_max_hp
	battle_panel.add_child(boss_hp_bar)

	slime_hp_bar = ProgressBar.new()
	slime_hp_bar.position = Vector2(785, 560)
	slime_hp_bar.size = Vector2(390, 34)
	slime_hp_bar.max_value = SLIME_MAX_HP
	battle_panel.add_child(slime_hp_bar)

	battle_status = Label.new()
	battle_status.position = Vector2(430, 600)
	battle_status.size = Vector2(380, 52)
	battle_status.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	battle_status.add_theme_font_size_override("font_size", 22)
	battle_panel.add_child(battle_status)

	boss_damage_label = _make_damage_label(Vector2(235, 180))
	battle_panel.add_child(boss_damage_label)
	slime_damage_label = _make_damage_label(Vector2(900, 220))
	battle_panel.add_child(slime_damage_label)

	battle_music = AudioStreamPlayer.new()
	battle_music.stream = BATTLE_THEME
	battle_music.volume_db = -13.0
	canvas.add_child(battle_music)
	sfx_player = AudioStreamPlayer.new()
	sfx_player.volume_db = 0.0
	canvas.add_child(sfx_player)

	# ---------- Post battle ----------
	post_panel = Panel.new()
	post_panel.position = Vector2(310, 160)
	post_panel.size = Vector2(660, 400)
	post_panel.visible = false
	canvas.add_child(post_panel)

	post_title = Label.new()
	post_title.position = Vector2(0, 24)
	post_title.size = Vector2(660, 50)
	post_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	post_title.add_theme_font_size_override("font_size", 30)
	post_panel.add_child(post_title)

	post_text = Label.new()
	post_text.position = Vector2(70, 95)
	post_text.size = Vector2(520, 150)
	post_text.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	post_text.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	post_text.add_theme_font_size_override("font_size", 22)
	post_panel.add_child(post_text)

	potion_button = Button.new()
	potion_button.text = "ใช้ Potion เล็ก (+30 HP)"
	potion_button.position = Vector2(90, 285)
	potion_button.size = Vector2(270, 64)
	potion_button.pressed.connect(_use_potion)
	post_panel.add_child(potion_button)

	continue_button = Button.new()
	continue_button.text = "เดินทางต่อ"
	continue_button.position = Vector2(385, 285)
	continue_button.size = Vector2(180, 64)
	continue_button.pressed.connect(_continue_after_battle)
	post_panel.add_child(continue_button)


func _make_damage_label(at: Vector2) -> Label:
	var label := Label.new()
	label.position = at
	label.size = Vector2(180, 70)
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.add_theme_font_size_override("font_size", 38)
	label.add_theme_color_override("font_color", Color("#fff2a8"))
	label.add_theme_color_override("font_shadow_color", Color("#571313"))
	label.add_theme_constant_override("shadow_offset_x", 3)
	label.add_theme_constant_override("shadow_offset_y", 3)
	label.visible = false
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return label


func _refresh_hud() -> void:
	hud_label.text = "Lv.%d   HP %d/%d   ATK %d   DEF %d   EXP %d   Potion x%d   แกนเวทย์ x%d" % [
		player_level, player_hp, player_max_hp, player_atk, player_def,
		player_exp, potions, small_magic_core
	]
	quest_label.text = "เควส: กำจัดสไลม์และเก็บแกนเวทย์ %d/10" % min(slime_kills, 10)

	if slime_kills >= 10:
		quest_label.text += "  [ครบแล้ว — กลับกิลด์ได้]"


# ============================================================
# AUTO BATTLE
# ============================================================

func _start_battle() -> void:
	if in_battle or not slime_active:
		return

	in_battle = true
	has_target = false
	player.velocity = Vector2.ZERO
	slime_hp = SLIME_MAX_HP

	battle_panel.visible = true
	boss_hp_bar.max_value = player_max_hp
	boss_hp_bar.value = player_hp
	slime_hp_bar.value = slime_hp
	battle_status.text = "เริ่มต่อสู้!"
	hint_label.text = "กำลังต่อสู้อัตโนมัติ"
	if not battle_music.playing:
		battle_music.play()

	call_deferred("_battle_loop")


func _battle_loop() -> void:
	await get_tree().create_timer(0.55).timeout

	var player_turn := player_spd >= SLIME_SPD

	while in_battle:
		if player_turn:
			var damage: int = max(1, player_atk - SLIME_DEF + randi_range(-1, 1))
			await _animate_boss_attack()
			slime_hp = max(0, slime_hp - damage)
			slime_hp_bar.value = slime_hp
			battle_status.text = "บอสฟาดด้วยมือเปล่า  %d Damage" % damage
			await _show_damage(slime_damage_label, damage)

			if slime_hp <= 0:
				await get_tree().create_timer(0.45).timeout
				_victory()
				return
		else:
			var damage: int = max(1, SLIME_ATK - player_def + randi_range(-1, 1))
			await _animate_slime_attack()
			player_hp = max(0, player_hp - damage)
			boss_hp_bar.value = player_hp
			battle_status.text = "Slime โจมตี %d Damage" % damage
			await _show_damage(boss_damage_label, damage)
			_refresh_hud()

			if player_hp <= 0:
				await get_tree().create_timer(0.45).timeout
				_defeat()
				return

		player_turn = not player_turn
		await get_tree().create_timer(0.55).timeout


func _animate_boss_attack() -> void:
	var original := boss_avatar.position
	sfx_player.stream = SFX_SWING
	sfx_player.play()
	var tween := create_tween()
	tween.tween_property(boss_avatar, "position", original + Vector2(125, 0), 0.12)
	tween.tween_property(slime_avatar, "modulate", Color("#fff0c2"), 0.04)
	tween.tween_property(slime_avatar, "modulate", Color.WHITE, 0.08)
	tween.tween_property(boss_avatar, "position", original, 0.14)
	await tween.finished
	sfx_player.stream = SFX_HIT
	sfx_player.play()
	await _battle_shake()


func _animate_slime_attack() -> void:
	var original := slime_avatar.position
	sfx_player.stream = SFX_SWING
	sfx_player.play()
	var tween := create_tween()
	tween.tween_property(slime_avatar, "position", original + Vector2(-95, 0), 0.14)
	tween.tween_property(boss_avatar, "modulate", Color("#ffb6b6"), 0.04)
	tween.tween_property(boss_avatar, "modulate", Color.WHITE, 0.08)
	tween.tween_property(slime_avatar, "position", original, 0.14)
	await tween.finished
	sfx_player.stream = SFX_HIT
	sfx_player.play()
	await _battle_shake()


func _show_damage(label: Label, damage: int) -> void:
	var start := label.position
	label.text = "-%d" % damage
	label.modulate = Color.WHITE
	label.scale = Vector2(0.65, 0.65)
	label.visible = true
	var tween := create_tween().set_parallel(true)
	tween.tween_property(label, "position", start + Vector2(0, -52), 0.34)
	tween.tween_property(label, "scale", Vector2(1.15, 1.15), 0.18)
	tween.tween_property(label, "modulate:a", 0.0, 0.34).set_delay(0.12)
	await tween.finished
	label.visible = false
	label.position = start


func _battle_shake() -> void:
	var home := battle_panel.position
	var tween := create_tween()
	tween.tween_property(battle_panel, "position", home + Vector2(-7, 3), 0.035)
	tween.tween_property(battle_panel, "position", home + Vector2(6, -2), 0.035)
	tween.tween_property(battle_panel, "position", home, 0.045)
	await tween.finished


func _victory() -> void:
	in_battle = false
	battle_music.stop()
	sfx_player.stream = SFX_VICTORY
	sfx_player.play()
	battle_panel.visible = false
	slime_active = false
	slime.visible = false

	player_exp += SLIME_EXP
	small_magic_core += 1
	slime_kills += 1

	var level_message := _check_level_up()

	post_battle = true
	player_was_defeated = false
	post_panel.visible = true
	post_title.text = "ชนะ!"
	post_text.text = "ได้รับ EXP +%d\nได้รับ แกนเวทย์ขนาดเล็ก x1\nHP ปัจจุบัน %d/%d%s" % [
		SLIME_EXP, player_hp, player_max_hp, level_message
	]
	_update_post_buttons()
	_refresh_hud()


func _defeat() -> void:
	in_battle = false
	battle_music.stop()
	battle_panel.visible = false
	slime_active = false
	slime.visible = false

	# Early-game defeat rule:
	# return to rest point, full HP, no loss of EXP/items/equipment.
	player_hp = player_max_hp
	player.position = Vector2(160, 390)

	post_battle = true
	player_was_defeated = true
	post_panel.visible = true
	post_title.text = "พ่ายแพ้"
	post_text.text = "กลับจุดพักในเมือง\nHP ฟื้นเต็ม\nไม่เสีย EXP เงิน หรืออุปกรณ์"
	_update_post_buttons()
	_refresh_hud()


func _check_level_up() -> String:
	var message := ""

	while player_level < exp_thresholds.size() and player_exp >= exp_thresholds[player_level]:
		player_level += 1
		player_max_hp += 8
		player_atk += 1

		# DEF +1 every two level gains: Lv.3, Lv.5, ...
		if player_level >= 3 and player_level % 2 == 1:
			player_def += 1

		player_hp = min(player_max_hp, player_hp + 20)
		message += "\nLEVEL UP! → Lv.%d  (HP+8, ATK+1, ฟื้น HP 20)" % player_level

	return message


# ============================================================
# POST BATTLE
# ============================================================

func _update_post_buttons() -> void:
	potion_button.disabled = player_was_defeated or potions <= 0 or player_hp >= player_max_hp
	potion_button.text = "ใช้ Potion เล็ก (+30 HP)  [x%d]" % potions


func _use_potion() -> void:
	# Potion is intentionally only available in this post-battle state.
	if not post_battle:
		return
	if potions <= 0 or player_hp >= player_max_hp:
		return

	potions -= 1
	player_hp = min(player_max_hp, player_hp + 30)
	post_text.text += "\nใช้ Potion → HP %d/%d" % [player_hp, player_max_hp]
	_update_post_buttons()
	_refresh_hud()


func _continue_after_battle() -> void:
	post_panel.visible = false
	post_battle = false
	player_was_defeated = false

	_respawn_slime()
	hint_label.text = "แตะพื้นที่บนฉากเพื่อเดินต่อ"


func _respawn_slime() -> void:
	# One prototype slime respawns farther along the route.
	var choices := [
		player.position.x + 540.0,
		player.position.x + 680.0,
		player.position.x - 520.0
	]
	slime.position = Vector2(choices[randi() % choices.size()], 390)
	slime_hp = SLIME_MAX_HP
	slime_active = true
	slime.visible = true
