extends Node2D

# ============================================================
# Prototype 01
# แตะหน้าจอ -> เดินอัตโนมัติ -> เจอสไลม์ -> Auto Battle
# -> EXP / แกนเวทย์ -> ใช้ Potion ได้หลังจบการต่อสู้เท่านั้น
# ============================================================

const MOVE_SPEED := 180.0

# ---------- Player balance ----------
var player_level := 1
var player_max_hp := 60
var player_hp := 60
var player_atk := 10
var player_def := 2
var player_spd := 6
var player_exp := 0
var small_magic_core := 0
var potions := 2

# EXP รวมที่ใช้ขึ้นเลเวล
var exp_thresholds := [0, 100, 280, 560, 960]

# ---------- Slime Lv.1 ----------
const SLIME_MAX_HP := 24
const SLIME_ATK := 4
const SLIME_DEF := 0
const SLIME_SPD := 2
const SLIME_EXP := 12

var slime_hp := SLIME_MAX_HP
var slime_active := true
var slime_kills := 0

# ---------- World state ----------
var player: CharacterBody2D
var player_body: Polygon2D
var slime: Node2D
var target_position := Vector2.ZERO
var has_target := false
var in_battle := false
var post_battle := false
var player_was_defeated := false

# ---------- UI ----------
var hud_label: Label
var quest_label: Label
var hint_label: Label

var battle_panel: Panel
var battle_status: Label
var boss_hp_bar: ProgressBar
var slime_hp_bar: ProgressBar
var boss_avatar: ColorRect
var slime_avatar: ColorRect

var post_panel: Panel
var post_title: Label
var post_text: Label
var potion_button: Button
var continue_button: Button


func _ready() -> void:
	randomize()
	_build_world()
	_build_ui()
	_refresh_hud()
	queue_redraw()


# ============================================================
# WORLD
# ============================================================

func _build_world() -> void:
	# Player
	player = CharacterBody2D.new()
	player.name = "Boss"
	player.position = Vector2(160, 390)
	add_child(player)

	player_body = Polygon2D.new()
	player_body.polygon = PackedVector2Array([
		Vector2(-18, -46),
		Vector2(18, -46),
		Vector2(26, -5),
		Vector2(19, 42),
		Vector2(-19, 42),
		Vector2(-26, -5)
	])
	player_body.color = Color("#7a5133")
	player.add_child(player_body)

	var belt := Polygon2D.new()
	belt.polygon = PackedVector2Array([
		Vector2(-25, -2), Vector2(25, -2),
		Vector2(25, 7), Vector2(-25, 7)
	])
	belt.color = Color("#35251b")
	player.add_child(belt)

	var player_name := Label.new()
	player_name.text = "บอส"
	player_name.position = Vector2(-24, -78)
	player_name.add_theme_font_size_override("font_size", 18)
	player.add_child(player_name)

	# Camera follows player so the scenery visibly scrolls while walking.
	var camera := Camera2D.new()
	camera.position_smoothing_enabled = true
	camera.position_smoothing_speed = 6.0
	camera.enabled = true
	player.add_child(camera)

	# Slime
	slime = Node2D.new()
	slime.name = "SlimeLv1"
	slime.position = Vector2(760, 390)
	add_child(slime)

	var slime_shape := Polygon2D.new()
	slime_shape.polygon = PackedVector2Array([
		Vector2(-34, 22),
		Vector2(-30, -6),
		Vector2(-18, -30),
		Vector2(0, -42),
		Vector2(18, -30),
		Vector2(30, -6),
		Vector2(34, 22),
		Vector2(0, 34)
	])
	slime_shape.color = Color("#4fbde8")
	slime.add_child(slime_shape)

	var slime_name := Label.new()
	slime_name.text = "Slime Lv.1"
	slime_name.position = Vector2(-48, -78)
	slime_name.add_theme_font_size_override("font_size", 17)
	slime.add_child(slime_name)


func _draw() -> void:
	# Large field
	draw_rect(Rect2(-2600, -500, 5200, 1800), Color("#68a94f"))

	# Dirt road
	draw_rect(Rect2(-2600, 315, 5200, 170), Color("#c9aa73"))
	draw_line(Vector2(-2600, 315), Vector2(2600, 315), Color("#8d744f"), 4.0)
	draw_line(Vector2(-2600, 485), Vector2(2600, 485), Color("#8d744f"), 4.0)

	# Decorative distant hills / trees — all move with the camera.
	for x in range(-2400, 2500, 420):
		draw_circle(Vector2(x, 185), 90.0, Color("#4c8e45"))
		draw_circle(Vector2(x + 100, 220), 65.0, Color("#579a4c"))

	# Fence posts along the route
	for x in range(-2400, 2500, 180):
		draw_rect(Rect2(x, 260, 12, 58), Color("#725135"))
		draw_rect(Rect2(x, 510, 12, 58), Color("#725135"))

	# A simple town silhouette in the far left
	draw_rect(Rect2(-1000, 90, 320, 190), Color("#d7c5a6"))
	draw_rect(Rect2(-900, 10, 90, 270), Color("#b9a37f"))
	draw_colored_polygon(
		PackedVector2Array([
			Vector2(-1030, 90), Vector2(-840, -45), Vector2(-650, 90)
		]),
		Color("#496f9f")
	)


func _physics_process(_delta: float) -> void:
	if in_battle or post_battle:
		player.velocity = Vector2.ZERO
		return

	if has_target:
		var delta_pos := target_position - player.global_position
		if delta_pos.length() <= 8.0:
			has_target = false
			player.velocity = Vector2.ZERO
		else:
			player.velocity = delta_pos.normalized() * MOVE_SPEED
			player.move_and_slide()

			# Small walk squash so movement is visibly animated even with placeholders.
			var phase := Time.get_ticks_msec() / 90.0
			player_body.scale.y = 1.0 + sin(phase) * 0.035
			player_body.scale.x = 1.0 - sin(phase) * 0.02
	else:
		player_body.scale = player_body.scale.lerp(Vector2.ONE, 0.25)

	if slime_active and player.global_position.distance_to(slime.global_position) < 82.0:
		_start_battle()


func _unhandled_input(event: InputEvent) -> void:
	if in_battle or post_battle:
		return

	var pressed := false
	var screen_pos := Vector2.ZERO

	if event is InputEventScreenTouch:
		pressed = event.pressed
		screen_pos = event.position
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		pressed = event.pressed
		screen_pos = event.position

	if pressed:
		var inv_canvas := get_viewport().get_canvas_transform().affine_inverse()
		target_position = inv_canvas * screen_pos
		has_target = true
		hint_label.text = "กำลังเดินอัตโนมัติ..."


# ============================================================
# UI
# ============================================================

func _build_ui() -> void:
	var canvas := CanvasLayer.new()
	add_child(canvas)

	hud_label = Label.new()
	hud_label.position = Vector2(24, 18)
	hud_label.add_theme_font_size_override("font_size", 22)
	canvas.add_child(hud_label)

	quest_label = Label.new()
	quest_label.position = Vector2(24, 56)
	quest_label.add_theme_font_size_override("font_size", 20)
	canvas.add_child(quest_label)

	hint_label = Label.new()
	hint_label.text = "แตะพื้นที่บนฉาก 1 ครั้ง แล้วบอสจะเดินไปเอง"
	hint_label.position = Vector2(24, 675)
	hint_label.add_theme_font_size_override("font_size", 18)
	canvas.add_child(hint_label)

	# ---------- Battle panel ----------
	battle_panel = Panel.new()
	battle_panel.position = Vector2(120, 110)
	battle_panel.size = Vector2(1040, 500)
	battle_panel.visible = false
	canvas.add_child(battle_panel)

	var battle_title := Label.new()
	battle_title.text = "AUTO BATTLE"
	battle_title.position = Vector2(430, 22)
	battle_title.add_theme_font_size_override("font_size", 28)
	battle_panel.add_child(battle_title)

	boss_avatar = ColorRect.new()
	boss_avatar.position = Vector2(160, 185)
	boss_avatar.size = Vector2(100, 150)
	boss_avatar.color = Color("#7a5133")
	battle_panel.add_child(boss_avatar)

	slime_avatar = ColorRect.new()
	slime_avatar.position = Vector2(780, 225)
	slime_avatar.size = Vector2(120, 95)
	slime_avatar.color = Color("#4fbde8")
	battle_panel.add_child(slime_avatar)

	var boss_name := Label.new()
	boss_name.text = "บอส"
	boss_name.position = Vector2(130, 120)
	boss_name.add_theme_font_size_override("font_size", 22)
	battle_panel.add_child(boss_name)

	var slime_name := Label.new()
	slime_name.text = "Slime Lv.1"
	slime_name.position = Vector2(760, 120)
	slime_name.add_theme_font_size_override("font_size", 22)
	battle_panel.add_child(slime_name)

	boss_hp_bar = ProgressBar.new()
	boss_hp_bar.position = Vector2(90, 365)
	boss_hp_bar.size = Vector2(280, 32)
	boss_hp_bar.max_value = player_max_hp
	battle_panel.add_child(boss_hp_bar)

	slime_hp_bar = ProgressBar.new()
	slime_hp_bar.position = Vector2(680, 365)
	slime_hp_bar.size = Vector2(280, 32)
	slime_hp_bar.max_value = SLIME_MAX_HP
	battle_panel.add_child(slime_hp_bar)

	battle_status = Label.new()
	battle_status.position = Vector2(330, 430)
	battle_status.size = Vector2(390, 50)
	battle_status.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	battle_status.add_theme_font_size_override("font_size", 22)
	battle_panel.add_child(battle_status)

	# ---------- Post battle ----------
	post_panel = Panel.new()
	post_panel.position = Vector2(310, 160)
	post_panel.size = Vector2(660, 400)
	post_panel.visible = false
	canvas.add_child(post_panel)

	post_title = Label.new()
	post_title.position = Vector2(0, 24)
	post_title.size = Vector2(660, 50)
	post_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	post_title.add_theme_font_size_override("font_size", 30)
	post_panel.add_child(post_title)

	post_text = Label.new()
	post_text.position = Vector2(70, 95)
	post_text.size = Vector2(520, 150)
	post_text.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	post_text.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	post_text.add_theme_font_size_override("font_size", 22)
	post_panel.add_child(post_text)

	potion_button = Button.new()
	potion_button.text = "ใช้ Potion เล็ก (+30 HP)"
	potion_button.position = Vector2(90, 285)
	potion_button.size = Vector2(270, 64)
	potion_button.pressed.connect(_use_potion)
	post_panel.add_child(potion_button)

	continue_button = Button.new()
	continue_button.text = "เดินทางต่อ"
	continue_button.position = Vector2(385, 285)
	continue_button.size = Vector2(180, 64)
	continue_button.pressed.connect(_continue_after_battle)
	post_panel.add_child(continue_button)


func _refresh_hud() -> void:
	hud_label.text = "Lv.%d   HP %d/%d   ATK %d   DEF %d   EXP %d   Potion x%d   แกนเวทย์ x%d" % [
		player_level, player_hp, player_max_hp, player_atk, player_def,
		player_exp, potions, small_magic_core
	]
	quest_label.text = "เควส: กำจัดสไลม์และเก็บแกนเวทย์ %d/10" % min(slime_kills, 10)

	if slime_kills >= 10:
		quest_label.text += "  [ครบแล้ว — กลับกิลด์ได้]"


# ============================================================
# AUTO BATTLE
# ============================================================

func _start_battle() -> void:
	if in_battle or not slime_active:
		return

	in_battle = true
	has_target = false
	player.velocity = Vector2.ZERO
	slime_hp = SLIME_MAX_HP

	battle_panel.visible = true
	boss_hp_bar.max_value = player_max_hp
	boss_hp_bar.value = player_hp
	slime_hp_bar.value = slime_hp
	battle_status.text = "เริ่มต่อสู้!"
	hint_label.text = "กำลังต่อสู้อัตโนมัติ"

	call_deferred("_battle_loop")


func _battle_loop() -> void:
	await get_tree().create_timer(0.55).timeout

	var player_turn := player_spd >= SLIME_SPD

	while in_battle:
		if player_turn:
			var damage: int = max(1, player_atk - SLIME_DEF + randi_range(-1, 1))
			await _animate_boss_attack()
			slime_hp = max(0, slime_hp - damage)
			slime_hp_bar.value = slime_hp
			battle_status.text = "บอสโจมตี %d Damage" % damage

			if slime_hp <= 0:
				await get_tree().create_timer(0.45).timeout
				_victory()
				return
		else:
			var damage: int = max(1, SLIME_ATK - player_def + randi_range(-1, 1))
			await _animate_slime_attack()
			player_hp = max(0, player_hp - damage)
			boss_hp_bar.value = player_hp
			battle_status.text = "Slime โจมตี %d Damage" % damage
			_refresh_hud()

			if player_hp <= 0:
				await get_tree().create_timer(0.45).timeout
				_defeat()
				return

		player_turn = not player_turn
		await get_tree().create_timer(0.55).timeout


func _animate_boss_attack() -> void:
	var original := boss_avatar.position
	var tween := create_tween()
	tween.tween_property(boss_avatar, "position", original + Vector2(95, 0), 0.14)
	tween.tween_property(boss_avatar, "position", original, 0.14)
	await tween.finished


func _animate_slime_attack() -> void:
	var original := slime_avatar.position
	var tween := create_tween()
	tween.tween_property(slime_avatar, "position", original + Vector2(-95, 0), 0.14)
	tween.tween_property(slime_avatar, "position", original, 0.14)
	await tween.finished


func _victory() -> void:
	in_battle = false
	battle_panel.visible = false
	slime_active = false
	slime.visible = false

	player_exp += SLIME_EXP
	small_magic_core += 1
	slime_kills += 1

	var level_message := _check_level_up()

	post_battle = true
	player_was_defeated = false
	post_panel.visible = true
	post_title.text = "ชนะ!"
	post_text.text = "ได้รับ EXP +%d\nได้รับ แกนเวทย์ขนาดเล็ก x1\nHP ปัจจุบัน %d/%d%s" % [
		SLIME_EXP, player_hp, player_max_hp, level_message
	]
	_update_post_buttons()
	_refresh_hud()


func _defeat() -> void:
	in_battle = false
	battle_panel.visible = false
	slime_active = false
	slime.visible = false

	# Early-game defeat rule:
	# return to rest point, full HP, no loss of EXP/items/equipment.
	player_hp = player_max_hp
	player.position = Vector2(160, 390)

	post_battle = true
	player_was_defeated = true
	post_panel.visible = true
	post_title.text = "พ่ายแพ้"
	post_text.text = "กลับจุดพักในเมือง\nHP ฟื้นเต็ม\nไม่เสีย EXP เงิน หรืออุปกรณ์"
	_update_post_buttons()
	_refresh_hud()


func _check_level_up() -> String:
	var message := ""

	while player_level < exp_thresholds.size() and player_exp >= exp_thresholds[player_level]:
		player_level += 1
		player_max_hp += 8
		player_atk += 1

		# DEF +1 every two level gains: Lv.3, Lv.5, ...
		if player_level >= 3 and player_level % 2 == 1:
			player_def += 1

		player_hp = min(player_max_hp, player_hp + 20)
		message += "\nLEVEL UP! → Lv.%d  (HP+8, ATK+1, ฟื้น HP 20)" % player_level

	return message


# ============================================================
# POST BATTLE
# ============================================================

func _update_post_buttons() -> void:
	potion_button.disabled = player_was_defeated or potions <= 0 or player_hp >= player_max_hp
	potion_button.text = "ใช้ Potion เล็ก (+30 HP)  [x%d]" % potions


func _use_potion() -> void:
	# Potion is intentionally only available in this post-battle state.
	if not post_battle:
		return
	if potions <= 0 or player_hp >= player_max_hp:
		return

	potions -= 1
	player_hp = min(player_max_hp, player_hp + 30)
	post_text.text += "\nใช้ Potion → HP %d/%d" % [player_hp, player_max_hp]
	_update_post_buttons()
	_refresh_hud()


func _continue_after_battle() -> void:
	post_panel.visible = false
	post_battle = false
	player_was_defeated = false

	_respawn_slime()
	hint_label.text = "แตะพื้นที่บนฉากเพื่อเดินต่อ"


func _respawn_slime() -> void:
	# One prototype slime respawns farther along the route.
	var choices := [
		player.position.x + 540.0,
		player.position.x + 680.0,
		player.position.x - 520.0
	]
	slime.position = Vector2(choices[randi() % choices.size()], 390)
	slime_hp = SLIME_MAX_HP
	slime_active = true
	slime.visible = true
